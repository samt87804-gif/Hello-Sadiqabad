---
name: Sadiqabad Civic Directory
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3d4a42'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6d7a72'
  outline-variant: '#bccac0'
  surface-tint: '#006c4a'
  primary: '#006948'
  on-primary: '#ffffff'
  primary-container: '#00855d'
  on-primary-container: '#f5fff7'
  inverse-primary: '#68dba9'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#006b2e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00873c'
  on-tertiary-container: '#f7fff3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#85f8c4'
  primary-fixed-dim: '#68dba9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#66ff8e'
  tertiary-fixed-dim: '#3de273'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005322'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '800'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  urdu-headline:
    fontFamily: Noto Nastaliq Urdu
    fontSize: 1.25rem
    fontWeight: '700'
    lineHeight: 2.6rem
  urdu-subtext:
    fontFamily: Noto Nastaliq Urdu
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.9rem
  urdu-chip:
    fontFamily: Noto Nastaliq Urdu
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1.6rem
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a warm, civic, and utilitarian identity tailored for the residents, merchants, and visitors of Sadiqabad. It bridges traditional local community trust with streamlined, high-speed digital directory utilities. The visual character balances clean civic modernism with localized Pakistani cultural accessibility: high legibility, functional color cues, instant contact actions, and bilingual harmony.

Key brand values:
- **Immediate Utility:** Frictionless search, direct dialing, and one-tap WhatsApp routing.
- **Civic Trust:** Dependable, institutional green anchors paired with vibrant amber commerce accents.
- **Inclusive Accessibility:** Purposefully designed for bilingual usage (English and Urdu Nastaliq), ensuring clear legibility across all age groups and network tiers.
- **Mobile-First Compactness:** Touch-centric tap targets, tactile feedback, and modular directory listing formats.

## Colors

The palette leverages deep evergreen and emerald tones honoring Pakistani civic tradition and regional pride, energized with an amber accent for local trade and spotlighting.

- **Primary (`#059669` / Deep Brand `#064e3b` / Bright Brand `#10b981`):** Primary branding, verified badges, active states, search buttons, and institutional headings.
- **Secondary (`#d97706`):** Accents, spotlight listings, featured trade promotions, ratings, and urgent service cues.
- **WhatsApp Action (`#25D366`):** Dedicated high-conversion utility color for instant local merchant messaging.
- **Surfaces & Canvases:** Clean slate background (`#f8fafc`) with crisp white card containers (`#ffffff`) framed by delicate borders (`#e2e8f0`).
- **Typography & Feedback:** Deep slate text (`#0f172a`) for maximum contrast, muted slate (`#64748b`) for subtitles and meta-details, danger crimson (`#dc2626`) for emergency listings, and success emerald (`#16a34a`) for open/operating status indicators.

## Typography

Typography prioritizes bilingual harmony and instant optical identification:

- **Primary Latin Script:** *Plus Jakarta Sans* delivers crisp, approachable sans-serif geometry with open letterforms, ideal for numbers, addresses, and directory taxonomy.
- **Urdu Script Hierarchy:** *Noto Nastaliq Urdu* provides culturally authentic typography. Because Nastaliq characters descend and ascend significantly, all Urdu-bearing elements must apply generous line-height multiplier (~2.0 - 2.2) and adequate vertical container padding (minimum 6px extra top and bottom) to strictly prevent ascender and descender clipping.
- **Bilingual Stacking:** Where Urdu hints accompany English terms (e.g., "Emergency / ایمرجنسی" or "Call / کال کریں"), the Urdu glyphs sit alongside or directly below the English text at an optically matched scale, treated as subtle contextual guidance.

## Layout & Spacing

The layout is built upon an 8px architectural grid system, optimized mobile-first to accommodate one-handed phone lookups in busy outdoor retail environments:

- **Mobile (< 640px):** Single-column directory stream, edge margins at `1rem` (16px), row gutters at `0.75rem` (12px) to `1rem` (16px). Quick category chips feature horizontal scroll with snap alignment.
- **Tablet (640px - 1024px):** 2-column card grid, `1.5rem` (24px) margins and gutters. Search input and key filter tools transition to sticky top banners.
- **Desktop (> 1024px):** 12-column responsive layout capped at a maximum width of 1200px. Left 3 columns reserved for taxonomy and neighborhood filters; right 9 columns host the directory listings grid (3 columns of listing cards).

## Elevation & Depth

Visual hierarchy uses crisp, clean surface isolation to ensure optimal readability under bright outdoor sunlight:

- **Layer 0 (Canvas):** `#f8fafc` flat background.
- **Layer 1 (Cards & Standard Surfaces):** `#ffffff` with a hairline stroke (`1px solid #e2e8f0`) and subtle diffuse shadow (`0 1px 3px rgba(15, 23, 42, 0.05)`).
- **Layer 2 (Elevated & Active Listings):** Premium or sponsored business cards feature a double-shadow technique (`0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`) with an amber or emerald highlight border.
- **Layer 3 (Modals, Action Sheets, Floating Emergency Bar):** Elevated z-index surfaces utilize `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.05)` with gentle backdrop blur (`backdrop-filter: blur(8px)`) over an alpha mask (`rgba(15, 23, 42, 0.4)`).

## Shapes

The interface embraces a friendly, tactile visual radius:

- **Directory Cards & Panels:** Standardized to a signature 16px corner radius (`rounded-lg` equivalent in this preset), imparting a welcoming, modern feel.
- **Input Fields & Search Bars:** 12px to 16px corner radius, matching the overarching card architecture.
- **Buttons & Contact Pills:** Primary actions, category chips, and contact triggers (Call, WhatsApp, Maps) utilize full pill-radii (`9999px`) or soft 12px curves for clear affordance and thumb-friendly interaction.
- **Emergency Indicators:** Angular badge accents or rounded badges within cards to separate critical municipal alerts from commercial listings.

## Components

### 1. Directory Listing Card
- **Structure:** 16px rounded surface in pure `#ffffff`, bordered by `#e2e8f0`.
- **Header:** Business/entity name in `Plus Jakarta Sans` (Semibold, 1.125rem) paired with localized Urdu category indicator. Verified badge (Lucide `CheckCircle2`) in `#059669`.
- **Body:** Address with landmark context, operating status indicator (Green dot: "Open now", Amber dot: "Closes soon"), and distance/area tag (e.g., "KLP Road", "Rail Bazaar").
- **Action Strip:** Sticky or bottom-anchored horizontal grid of contact tools:
  - **Direct Call:** Phone icon button in `#f1f5f9` with `#0f172a` text ("Call / کال کریں").
  - **WhatsApp Direct:** Dedicated button in `#25D366` with white text ("WhatsApp / واٹس ایپ").
  - **Directions:** Map pin icon button ("Route / راستہ").

### 2. Search & Filter Bar
- **Architecture:** High-visibility hero container with multi-input fields (keyword query and neighborhood selector).
- **Icons:** Lucide `Search` in `#64748b`, trailing `X` clear action, and Lucide `MapPin` for Sadiqabad tehsils/sectors.
- **Bilingual Cue:** Floating placeholder: "Search doctor, shop, plumber... / تلاش کریں".

### 3. Category Chips & Filter Pills
- **Style:** Compact pill shape (`rounded-full`), vertical padding adjusted to give clearance for Nastaliq glyphs.
- **States:** Inactive chips feature `#ffffff` background, `1px solid #e2e8f0`, text `#64748b`. Active state shifts to `#064e3b` background with white text and a contrasting count badge.

### 4. Interactive Action Buttons
- **Primary Buttons:** High-contrast `#059669` fill, white bold label, 44px minimum tap target height.
- **Urgent / Emergency Utility:** Bright red `#dc2626` base with white text and pulsating siren icon for ambulance, fire brigade, and police helplines.
- **Secondary Actions:** Subtle slate tint `#f1f5f9` with `#0f172a` text and borderless active depth.

### 5. Input Fields & Selectors
- **Style:** 16px rounded corners, `#ffffff` surface, `#e2e8f0` stroke, 48px height for touch convenience.
- **Focus:** Crisp focus ring: `2px solid #059669` with `0 0 0 3px rgba(5, 150, 105, 0.15)`.
- **Directional Support:** Automatic RTL alignment for Urdu inputs; default LTR with left-aligned icons for English and phone number inputs.